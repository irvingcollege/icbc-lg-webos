# ICBC LG submission preparation 1.0.1

Start with submission/README.md. The IPK is in package/. This is a preparation pack, not an approved or completed submission. Physical-TV, catalog CORS and LG official-form gates remain.
